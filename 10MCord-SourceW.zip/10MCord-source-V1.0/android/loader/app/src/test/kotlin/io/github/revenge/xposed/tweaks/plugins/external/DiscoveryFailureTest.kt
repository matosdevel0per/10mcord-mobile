package io.github.revenge.xposed.tweaks.plugins.external


import io.github.revenge.plugins.API_DEPENDENCY_ID
import io.github.revenge.plugins.DISCORD_DEPENDENCY_ID
import io.github.revenge.plugins.PluginManifest
import io.github.revenge.plugins.Version
import io.github.revenge.xposed.tweaks.plugins.PluginDependencyGraph
import io.github.revenge.xposed.tweaks.plugins.PluginErrorCodes
import io.github.revenge.xposed.tweaks.plugins.externalPluginsRoot
import java.io.File
import java.nio.file.Files
import kotlin.test.*

/**
 * Unsatisfied/missing dependencies, cascades, cycles, and unparseable manifests must surface as [DiscoveryFailure]s
 * instead of vanishing and appearing in logs only.
 */
class DiscoveryFailureTest {
    private val dataDir: File = Files.createTempDirectory("revenge-discovery-test").toFile()

    /** The reserved dependencies, which every plugin below declares. */
    private val knownManifests = listOf(
        API_DEPENDENCY_ID to Version.parse("1.0.0"),
        DISCORD_DEPENDENCY_ID to Version.parse("0"),
    ).associate { (id, version) ->
        id to PluginManifest(id, id, "", "", version = version)
    }

    @AfterTest
    fun cleanup() {
        dataDir.deleteRecursively()
    }

    private fun writePlugin(
        id: String,
        version: String = "1.0.0",
        dependencies: String = "",
        manifestJson: String? = null,
    ) {
        val dir = File(externalPluginsRoot(dataDir.absolutePath), id).apply { mkdirs() }
        val deps = buildString {
            append("\"$API_DEPENDENCY_ID\": {}, \"$DISCORD_DEPENDENCY_ID\": {}")
            if (dependencies.isNotEmpty()) append(", $dependencies")
        }
        File(dir, "manifest.json").writeText(
            manifestJson ?: """
            {
                "format": 1,
                "id": "$id",
                "name": "Test $id",
                "version": "$version",
                "dependencies": { $deps },
                "dist": { "script": "plugin.js" }
            }
            """.trimIndent(),
        )
        File(dir, "plugin.js").writeText("() => ({})")
    }

    private fun discover() = discoverExternalPlugins(dataDir.absolutePath, knownManifests)

    /** Discovery chains nothing, so what a plugin *may* link is the graph's answer until it is realized. */
    private fun ExternalDiscovery.satisfiedFor(id: String): Set<String> =
        PluginDependencyGraph(knownManifests + factories.associate { it.manifest.id to it.manifest })
            .satisfiedDependencies(id)

    // Stub plugins are handled outside the Discovery flow and tested in StubPluginTest.
    @Test
    fun `installed copy of an internal plugin is ignored and does not replace its manifest`() {
        val internalId = "com.example.internal"
        val internals = knownManifests +
                (internalId to PluginManifest(internalId, internalId, "", "", version = Version.parse("1.0.0")))
        writePlugin(internalId, version = "2.0.0")
        writePlugin("com.example.dependent", dependencies = "\"$internalId\": { \"version\": \">=2\" }")

        val discovery = discoverExternalPlugins(dataDir.absolutePath, internals)

        assertTrue(discovery.factories.none { it.manifest.id == internalId })
        assertTrue(internalId !in discovery.failures)
        // The dependent resolves against the internal 1.0.0, not the ignored 2.0.0 copy.
        assertEquals(
            PluginErrorCodes.DEPENDENCY_UNSATISFIED,
            discovery.failures["com.example.dependent"]?.errors?.single()?.code,
        )
    }

    @Test
    fun `valid plugin loads with no failures`() {
        writePlugin("com.example.ok")

        val discovery = discover()

        assertEquals(listOf("com.example.ok"), discovery.factories.map { it.manifest.id })
        assertTrue(discovery.failures.isEmpty())
    }

    @Test
    fun `missing required dependency session-skips with a parsed manifest and reason`() {
        writePlugin("com.example.broken", dependencies = "\"com.example.gone\": {}")

        val discovery = discover()

        assertTrue(discovery.factories.isEmpty())
        val failure = discovery.failures["com.example.broken"]
        assertNotNull(failure)
        assertNotNull(failure.manifest)
        assertEquals("com.example.broken", failure.manifest.id)
        val error = failure.errors.single()
        assertEquals(PluginErrorCodes.DEPENDENCY_MISSING, error.code)
        assertTrue("missing dependency 'com.example.gone'" in error.message)
        // Environmental failure: keeps the enabled flag, session-skip only.
        assertTrue(!failure.isPluginFault)
    }

    @Test
    fun `every unsatisfied required dependency is reported, not just the first`() {
        writePlugin("com.example.old", version = "1.0.0")
        writePlugin(
            "com.example.broken",
            dependencies = "\"com.example.gone\": {}, \"com.example.old\": { \"version\": \">=2\" }",
        )

        val discovery = discover()

        val failure = discovery.failures["com.example.broken"]
        assertNotNull(failure)
        assertEquals(2, failure.errors.size)
        assertEquals(
            setOf(PluginErrorCodes.DEPENDENCY_MISSING, PluginErrorCodes.DEPENDENCY_UNSATISFIED),
            failure.errors.map { it.code }.toSet(),
        )
        assertTrue(failure.errors.any { "com.example.gone" in it.message })
        assertTrue(failure.errors.any { "com.example.old" in it.message })
    }

    @Test
    fun `every failed required dependency is reported to the dependent`() {
        writePlugin("com.example.bad1", dependencies = "\"com.example.gone\": {}")
        writePlugin("com.example.bad2", dependencies = "\"com.example.gone\": {}")
        writePlugin(
            "com.example.top",
            dependencies = "\"com.example.bad1\": {}, \"com.example.bad2\": {}",
        )

        val discovery = discover()

        val top = discovery.failures["com.example.top"]
        assertNotNull(top)
        assertEquals(2, top.errors.size)
        assertTrue(top.errors.all { it.code == PluginErrorCodes.DEPENDENCY_MISSING })
        assertTrue(top.errors.any { "com.example.bad1" in it.message })
        assertTrue(top.errors.any { "com.example.bad2" in it.message })
    }

    @Test
    fun `version-unsatisfied required dependency session-skips`() {
        writePlugin("com.example.dep", version = "1.0.0")
        writePlugin("com.example.needy", dependencies = "\"com.example.dep\": { \"version\": \">=2\" }")

        val discovery = discover()

        assertEquals(listOf("com.example.dep"), discovery.factories.map { it.manifest.id })
        val failure = discovery.failures["com.example.needy"]
        assertNotNull(failure)
        val error = failure.errors.single()
        assertEquals(PluginErrorCodes.DEPENDENCY_UNSATISFIED, error.code)
        assertTrue("does not satisfy" in error.message)
    }

    @Test
    fun `required-dependency failure cascades to dependents`() {
        writePlugin("com.example.mid", dependencies = "\"com.example.gone\": {}")
        writePlugin("com.example.top", dependencies = "\"com.example.mid\": {}")

        val discovery = discover()

        assertTrue(discovery.factories.isEmpty())
        assertNotNull(discovery.failures["com.example.mid"])
        val top = discovery.failures["com.example.top"]
        assertNotNull(top)
        val error = top.errors.single()
        assertEquals(PluginErrorCodes.DEPENDENCY_MISSING, error.code)
        assertTrue("com.example.mid" in error.message)
    }

    @Test
    fun `missing optional dependency never blocks the dependent`() {
        writePlugin("com.example.tolerant", dependencies = "\"com.example.gone\": { \"optional\": true }")

        val discovery = discover()

        assertEquals(listOf("com.example.tolerant"), discovery.factories.map { it.manifest.id })
        assertTrue(discovery.failures.isEmpty())
        // Absent, so nothing to chain.
        assertTrue("com.example.gone" !in discovery.satisfiedFor("com.example.tolerant"))
    }

    @Test
    fun `present-but-unsatisfied optional dependency is reported`() {
        writePlugin("com.example.dep", version = "1.0.0")
        writePlugin(
            "com.example.tolerant",
            dependencies = "\"com.example.dep\": { \"version\": \">=2\", \"optional\": true }",
        )

        val discovery = discover()

        assertEquals(
            setOf("com.example.dep", "com.example.tolerant"),
            discovery.factories.map { it.manifest.id }.toSet(),
        )
        assertTrue(discovery.failures.isEmpty())
        // Present but out of range, so it can never be chained.
        assertTrue("com.example.dep" !in discovery.satisfiedFor("com.example.tolerant"))
    }

    @Test
    fun `satisfied optional dependency is not reported`() {
        writePlugin("com.example.dep", version = "2.0.0")
        writePlugin(
            "com.example.tolerant",
            dependencies = "\"com.example.dep\": { \"version\": \">=2\", \"optional\": true }",
        )

        val discovery = discover()

        assertTrue(discovery.failures.isEmpty())
        assertTrue("com.example.dep" in discovery.satisfiedFor("com.example.tolerant"))
    }

    @Test
    fun `discovery loads no plugin code`() {
        writePlugin("com.example.ok")

        val factory = discover().factories.single()

        assertNull(factory.chainedDependencies, "discovery must not build a plugin the user may have disabled")
    }

    @Test
    fun `dependency cycle session-skips every member`() {
        writePlugin("com.example.a", dependencies = "\"com.example.b\": {}")
        writePlugin("com.example.b", dependencies = "\"com.example.a\": {}")

        val discovery = discover()

        assertTrue(discovery.factories.isEmpty())
        assertEquals(
            PluginErrorCodes.DEPENDENCY_CYCLE,
            discovery.failures["com.example.a"]?.errors?.single()?.code,
        )
        assertEquals(true, discovery.failures["com.example.a"]?.errors?.single()?.message?.contains("cycle"))
        assertEquals(true, discovery.failures["com.example.b"]?.errors?.single()?.message?.contains("cycle"))
    }

    @Test
    fun `unparseable manifest fails keyed by directory name with no manifest`() {
        writePlugin("com.example.junk", manifestJson = "{ not json")

        val discovery = discover()

        assertTrue(discovery.factories.isEmpty())
        val failure = discovery.failures["com.example.junk"]
        assertNotNull(failure)
        assertEquals(PluginErrorCodes.MANIFEST_INVALID, failure.errors.single().code)
        assertNull(failure.manifest)
        // Own-fault failure: the boot pass disables the plugin.
        assertTrue(failure.isPluginFault)
    }

    @Test
    fun `manifest missing a reserved dependency is rejected at parse`() {
        writePlugin(
            "com.example.undeclared",
            manifestJson = """
            {
                "format": 1,
                "id": "com.example.undeclared",
                "name": "Undeclared",
                "version": "1.0.0",
                "dependencies": { "$API_DEPENDENCY_ID": {} }
            }
            """.trimIndent(),
        )

        val discovery = discover()

        assertTrue(discovery.factories.isEmpty())
        val failure = discovery.failures["com.example.undeclared"]
        assertNotNull(failure)
        assertNull(failure.manifest)
    }

    @Test
    fun `failures never remove plugin directories`() {
        writePlugin("com.example.broken", dependencies = "\"com.example.gone\": {}")

        discover()

        assertTrue(File(externalPluginsRoot(dataDir.absolutePath), "com.example.broken").isDirectory)
    }

    @Test
    fun `plugins load in dependency order`() {
        writePlugin("com.example.top", dependencies = "\"com.example.dep\": {}")
        writePlugin("com.example.dep")

        val discovery = discover()

        assertEquals(
            listOf("com.example.dep", "com.example.top"),
            discovery.factories.map { it.manifest.id },
        )
        assertTrue(discovery.failures.isEmpty())
    }

    @Test
    fun `discovery ignores dot-directories and cleans up orphaned temp dirs`() {
        writePlugin("com.example.ok")
        // A crash-orphaned staged install: contains a valid manifest but must never be discovered.
        val orphan = File(externalPluginsRoot(dataDir.absolutePath), ".confirm-abc").apply { mkdirs() }
        File(orphan, "manifest.json").writeText(
            File(File(externalPluginsRoot(dataDir.absolutePath), "com.example.ok"), "manifest.json").readText(),
        )
        val dexCache = File(externalPluginsRoot(dataDir.absolutePath), ".dex-cache").apply { mkdirs() }

        val discovery = discover()

        assertEquals(listOf("com.example.ok"), discovery.factories.map { it.manifest.id })
        assertTrue(discovery.failures.isEmpty())
        assertTrue(!orphan.exists(), "orphaned staged dir should be cleaned up")
        assertTrue(dexCache.isDirectory, "the dex cache must survive cleanup")
    }
}

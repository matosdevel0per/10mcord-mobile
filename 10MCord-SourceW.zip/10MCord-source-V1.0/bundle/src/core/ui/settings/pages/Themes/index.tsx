import { formatString, Strings, t } from "@core/i18n";
import AddonPage from "@core/ui/components/AddonPage";
import ThemeCard from "@core/ui/settings/pages/Themes/ThemeCard";
import { useProxy } from "@core/vendetta/storage";
import { getCurrentTheme, installTheme, themes, VdThemeInfo } from "@lib/addons/themes";
import { colorsPref } from "@lib/addons/themes/colors/preferences";
import { updateBunnyColor } from "@lib/addons/themes/colors/updater";
import { Author } from "@lib/addons/types";
import { findAssetId } from "@lib/api/assets";
import { settings } from "@lib/api/settings";
import { useObservable } from "@lib/api/storage";
import compareNames from "@lib/utils/compareNames";
import { ActionSheet, BottomSheetTitleHeader, Button, TableRadioGroup, TableRadioRow,TableRow, TableRowGroup, TableRowIcon, TableSwitchRow } from "@metro/common/components";
import { View } from "react-native";

export default function Themes() {
    useProxy(settings);
    useProxy(themes);

    return (
        <AddonPage<VdThemeInfo>
            title={Strings.THEMES}
            searchKeywords={[
                "data.name",
                "data.description",
                p => p.data.authors?.map((a: Author) => a.name).join(", ") ?? ""
            ]}
            sortOptions={{
                [t("Name (A-Z)")]: (a, b) => compareNames(a.data.name, b.data.name),
                [t("Name (Z-A)")]: (a, b) => compareNames(b.data.name, a.data.name)
            }}
            installAction={{
                label: Strings.INSTALL_THEME,
                fetchFn: installTheme
            }}
            items={Object.values(themes)}
            safeModeHint={{
                message: formatString("SAFE_MODE_NOTICE_THEMES", { enabled: Boolean(settings.safeMode?.currentThemeId) }),
                footer: settings.safeMode?.currentThemeId && <Button
                    size="small"
                    text={Strings.DISABLE_THEME}
                    onPress={() => delete settings.safeMode?.currentThemeId}
                    style={{ marginTop: 8 }}
                />
            }}
            CardComponent={ThemeCard}
            OptionsActionSheetComponent={() => {
                useObservable([colorsPref]);

                return <ActionSheet>
                    <BottomSheetTitleHeader title={t("Options")} />
                    <View style={{ paddingVertical: 20, gap: 12 }}>
                        <TableRadioGroup
                            title={t("Theme type")}
                            defaultValue={colorsPref.type ?? "auto"}
                            hasIcons={true}
                            onChange={type => {
                                colorsPref.type = type !== "auto" ? type as "dark" | "light" : undefined;
                                getCurrentTheme()?.data && updateBunnyColor(getCurrentTheme()!.data!, { update: true });
                            }}
                        >
                            <TableRadioRow icon={<TableRowIcon source={findAssetId("RobotIcon")} />} label={t("Automatic")} value="auto" />
                            <TableRadioRow icon={<TableRowIcon source={findAssetId("ThemeDarkIcon")} />} label={t("Dark")} value="dark" />
                            <TableRadioRow icon={<TableRowIcon source={findAssetId("ThemeLightIcon")} />} label={t("Light")} value="light" />
                        </TableRadioGroup>

                        <TableRowGroup title={t("Settings")}>
                            <TableSwitchRow
                                label={t("Show chat background")}
                                subLabel={t("Shows or hides the theme's background image in chat")}
                                icon={<TableRow.Icon source={findAssetId("ImageIcon")} />}
                                value={colorsPref.customBackground !== "hidden"}
                                onValueChange={value => {
                                    colorsPref.customBackground = value ? null : "hidden";
                                }}
                            />
                        </TableRowGroup>
                    </View>
                </ActionSheet>;
            }}
        />
    );
}

import { Strings } from "@core/i18n";
import { VdPluginManager, VendettaPlugin } from "@core/vendetta/plugins";
import { ApplicationCommand, ApplicationCommandOptionType } from "@lib/api/commands/types";
import compareNames from "@lib/utils/compareNames";
import { messageUtil } from "@metro/common";

export default () => <ApplicationCommand>{
    name: "plugins",
    description: Strings.COMMAND_PLUGINS_DESC,
    options: [
        {
            name: "ephemeral",
            displayName: "ephemeral",
            type: ApplicationCommandOptionType.BOOLEAN,
            description: Strings.COMMAND_DEBUG_OPT_EPHEMERALLY,
        }
    ],
    execute([ephemeral], ctx) {
        const plugins = Object.values(VdPluginManager.plugins).filter(Boolean) as unknown as VendettaPlugin[];
        plugins.sort((a, b) => compareNames(a.manifest.name, b.manifest.name));

        const enabled = plugins.filter(p => p.enabled).map(p => p.manifest.name);
        const disabled = plugins.filter(p => !p.enabled).map(p => p.manifest.name);

        const content = [
            `**Installed Plugins (${plugins.length}):**`,
            ...(enabled.length > 0 ? [
                `Enabled (${enabled.length}):`,
                "> " + enabled.join(", "),
            ] : []),
            ...(disabled.length > 0 ? [
                `Disabled (${disabled.length}):`,
                "> " + disabled.join(", "),
            ] : []),
        ].join("\n");

        if (ephemeral?.value) {
            messageUtil.sendBotMessage(ctx.channel.id, content);
        } else {
            const fixNonce = Date.now().toString();
            messageUtil.sendMessage(ctx.channel.id, { content }, void 0, { nonce:fixNonce });
        }
    }
};

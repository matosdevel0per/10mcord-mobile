/*
 * ShiftCord for Android
 * Copyright (c) 2026 rootpoi and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { t, tx } from "@core/i18n";

import { definePlugin } from "../api";
import { addMessageAction, copy } from "../hooks";
import { pickOne } from "../shared/actions";

const emojisIn = (content: string) => [...new Set(content.match(/<a?:\w+:\d+>/g) ?? [])];

export default definePlugin({
    id: "10MCord.copy-emoji-markdown",
    name: "CopyEmojiMarkdown",
    description: tx("Allows you to copy emojis as formatted string (<:blobcatcozy:1026533070955872337>)"),
    icon: "ReactionIcon",
    tags: ["Emotes"],
    start({ cleanup }) {
        cleanup(addMessageAction({
            key: "copy-emoji-markdown",
            icon: "ReactionIcon",
            label: () => t("Copy Emoji Markdown"),
            visible: message => emojisIn(message.content ?? "").length > 0,
            onPress: message => pickOne(t("Copy Emoji Markdown"), emojisIn(message.content), e => e.replace(/^<a?:(\w+):\d+>$/, ":$1:"), e => copy(e)),
        }));
    },
});
